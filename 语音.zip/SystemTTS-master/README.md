# SystemTTS
Android系统语音播报

https://developer.android.google.cn/reference/android/speech/tts/TextToSpeech.html
